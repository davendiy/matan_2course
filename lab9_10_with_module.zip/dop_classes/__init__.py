#!/usr/bin/env python3
# -*-encoding: utf-8-*-

# by David Zashkol
# 2 course, comp math
# Taras Shevchenko National University of Kyiv
# email: davendiy@gmail.com

"""
пакет з додатковими класами для лабораторних, який, мабуть,
буду постійно доробляти
"""

from .multydimensional import *
from .partions_danil import *
from .module_plot import *
from .solve_equations import *
